# SmartCampus — Entidades e relações (modelo inicial, revisão 2)

O ficheiro PNG incluído é a última versão visual do diagrama criada na conversa.
Este texto regista explicitamente as regras confirmadas e a nomenclatura a
utilizar na documentação antes da implementação da base de dados.

## Entidades principais

- **Sala**: identifica um espaço.
- **Armário**: pertence a uma sala.
- **Equipamento**: está associado diretamente a uma sala **ou** a um armário.
- **Utilizador**: pode ser aluno, professor ou responsável, com permissões diferentes.
- **Assignação**: equipamento, destinatário, utilizador que assignou, data de início.
- **Devolução**: assignação, utilizador que registou a devolução, data e hora.
- **Avaria**: equipamento, utilizador que a registou, data, descrição e estado; quando
  resolvida, data de resolução e **utilizador que registou a resolução**.
- **Transferência**: equipamento ou armário, origem, destino, data e hora,
  utilizador que registou.
- **Evento**: registo de uma operação que pode alimentar a Central de Avisos.
- **Aviso**: aviso associado a um evento.

## Relações e regras

1. Uma sala pode conter vários armários; cada armário pertence a uma sala.
2. Um equipamento pertence a uma localização direta de cada vez: sala ou armário.
3. A transferência de um armário move também os equipamentos nele associados.
4. Um equipamento pode ter várias assignações ao longo do tempo.
5. Uma assignação pode ter uma devolução, registada por utilizador diferente
   daquele que fez a assignação.
6. Um equipamento pode ter várias avarias. Quem regista a abertura e quem regista
   a resolução podem ser pessoas diferentes.
7. Uma avaria origina uma transferência para a Sala Reparações.
8. As transferências têm um utilizador responsável pelo registo.
9. Os eventos podem gerar avisos, cujo resumo aparece no Dashboard.

## Campos e relações ainda a validar

- Tipos de equipamentos abrangidos definitivamente pelo projeto-piloto.
- Critérios de criação de avisos, prazos e limites de assignações.
- Modelo detalhado de permissões e autenticação.
- Campos obrigatórios e estados de cada operação.
- Destino e operação de transferência depois de uma reparação.

**Correção de terminologia:** onde a imagem diz
`id_utilizador_resolveu`, deve ler-se
`id_utilizador_registou_resolucao`. A pessoa que registou a resolução não é
necessariamente quem efetuou a reparação.
